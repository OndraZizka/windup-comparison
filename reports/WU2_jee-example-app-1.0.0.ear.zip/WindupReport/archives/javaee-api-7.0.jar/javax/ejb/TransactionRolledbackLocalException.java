package javax.ejb;

public class TransactionRolledbackLocalException extends EJBException{
    private static final long serialVersionUID=2897658132751784821L;
    public TransactionRolledbackLocalException(){
        super();
    }
    public TransactionRolledbackLocalException(final String message){
        super(message);
    }
    public TransactionRolledbackLocalException(final String message,final Exception ex){
        super(message,ex);
    }
}
