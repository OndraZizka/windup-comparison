package com.sun.mail.util;

import java.lang.reflect.*;
import javax.mail.internet.*;
import java.security.*;

public class MimeUtil{
    private static final Method cleanContentType;
    public static String cleanContentType(final MimePart mp,final String contentType){
        if(MimeUtil.cleanContentType!=null){
            try{
                return (String)MimeUtil.cleanContentType.invoke(null,new Object[] { mp,contentType });
            }
            catch(Exception ex){
                return contentType;
            }
        }
        return contentType;
    }
    private static ClassLoader getContextClassLoader(){
        return (ClassLoader)AccessController.doPrivileged(new PrivilegedAction(){
            public Object run(){
                ClassLoader cl=null;
                try{
                    cl=Thread.currentThread().getContextClassLoader();
                }
                catch(SecurityException ex){
                }
                return cl;
            }
        });
    }
    static{
        Method meth=null;
        try{
            final String cth=System.getProperty("mail.mime.contenttypehandler");
            if(cth!=null){
                final ClassLoader cl=getContextClassLoader();
                Class clsHandler=null;
                if(cl!=null){
                    try{
                        clsHandler=Class.forName(cth,false,cl);
                    }
                    catch(ClassNotFoundException ex4){
                    }
                }
                if(clsHandler==null){
                    clsHandler=Class.forName(cth);
                }
                meth=clsHandler.getMethod("cleanContentType",new Class[] { MimePart.class,String.class });
            }
            cleanContentType=meth;
        }
        catch(ClassNotFoundException ex){
            cleanContentType=meth;
        }
        catch(NoSuchMethodException ex2){
            cleanContentType=meth;
        }
        catch(RuntimeException ex3){
            cleanContentType=meth;
        }
        finally{
            cleanContentType=meth;
        }
    }
}
