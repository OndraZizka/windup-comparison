package javax.mail;

public class AuthenticationFailedException extends MessagingException{
    private static final long serialVersionUID=492080754054436511L;
    public AuthenticationFailedException(){
        super();
    }
    public AuthenticationFailedException(final String message){
        super(message);
    }
    public AuthenticationFailedException(final String message,final Exception e){
        super(message,e);
    }
}
