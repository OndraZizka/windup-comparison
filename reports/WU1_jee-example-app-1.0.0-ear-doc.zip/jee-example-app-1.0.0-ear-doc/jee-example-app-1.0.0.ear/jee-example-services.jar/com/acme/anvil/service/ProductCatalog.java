// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: fullnames 
// Source File Name:   ProductCatalog.java

package com.acme.anvil.service;

import javax.ejb.EJBObject;

public interface ProductCatalog
    extends javax.ejb.EJBObject
{

    public abstract void populateCatalog();
}
