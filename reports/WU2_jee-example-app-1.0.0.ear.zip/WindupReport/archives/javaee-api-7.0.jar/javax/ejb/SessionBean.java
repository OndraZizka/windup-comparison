package javax.ejb;

import java.rmi.*;

public interface SessionBean extends EnterpriseBean{
    void setSessionContext(SessionContext p0) throws EJBException,RemoteException;
    void ejbRemove() throws EJBException,RemoteException;
    void ejbActivate() throws EJBException,RemoteException;
    void ejbPassivate() throws EJBException,RemoteException;
}
