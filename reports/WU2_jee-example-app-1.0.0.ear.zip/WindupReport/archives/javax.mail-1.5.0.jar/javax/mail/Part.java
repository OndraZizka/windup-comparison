package javax.mail;

import javax.activation.*;
import java.io.*;
import java.util.*;

public interface Part{
    public static final String ATTACHMENT="attachment";
    public static final String INLINE="inline";
    int getSize() throws MessagingException;
    int getLineCount() throws MessagingException;
    String getContentType() throws MessagingException;
    boolean isMimeType(String p0) throws MessagingException;
    String getDisposition() throws MessagingException;
    void setDisposition(String p0) throws MessagingException;
    String getDescription() throws MessagingException;
    void setDescription(String p0) throws MessagingException;
    String getFileName() throws MessagingException;
    void setFileName(String p0) throws MessagingException;
    InputStream getInputStream() throws IOException,MessagingException;
    DataHandler getDataHandler() throws MessagingException;
    Object getContent() throws IOException,MessagingException;
    void setDataHandler(DataHandler p0) throws MessagingException;
    void setContent(Object p0,String p1) throws MessagingException;
    void setText(String p0) throws MessagingException;
    void setContent(Multipart p0) throws MessagingException;
    void writeTo(OutputStream p0) throws IOException,MessagingException;
    String[] getHeader(String p0) throws MessagingException;
    void setHeader(String p0,String p1) throws MessagingException;
    void addHeader(String p0,String p1) throws MessagingException;
    void removeHeader(String p0) throws MessagingException;
    Enumeration getAllHeaders() throws MessagingException;
    Enumeration getMatchingHeaders(String[] p0) throws MessagingException;
    Enumeration getNonMatchingHeaders(String[] p0) throws MessagingException;
}
