package javax.ejb;

public interface EJBLocalHome{
    void remove(Object p0) throws RemoveException,EJBException;
}
