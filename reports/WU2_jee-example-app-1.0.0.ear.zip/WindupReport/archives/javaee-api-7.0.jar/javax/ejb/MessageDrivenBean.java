package javax.ejb;

public interface MessageDrivenBean extends EnterpriseBean{
    void setMessageDrivenContext(MessageDrivenContext p0) throws EJBException;
    void ejbRemove() throws EJBException;
}
