package javax.ejb.spi;

import java.util.*;
import javax.ejb.embeddable.*;
import javax.ejb.*;

public interface EJBContainerProvider{
    EJBContainer createEJBContainer(Map<?,?> p0) throws EJBException;
}
