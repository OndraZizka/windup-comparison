package org.apache.log4j.lf5.viewer;

import javax.swing.*;
import java.awt.*;

public class LogFactor5LoadingDialog extends LogFactor5Dialog{
    public LogFactor5LoadingDialog(final JFrame jframe,final String message){
        super(jframe,"LogFactor5",false);
        final JPanel bottom=new JPanel();
        bottom.setLayout(new FlowLayout());
        final JPanel main=new JPanel();
        main.setLayout(new GridBagLayout());
        this.wrapStringOnPanel(message,main);
        this.getContentPane().add(main,"Center");
        this.getContentPane().add(bottom,"South");
        this.show();
    }
}
