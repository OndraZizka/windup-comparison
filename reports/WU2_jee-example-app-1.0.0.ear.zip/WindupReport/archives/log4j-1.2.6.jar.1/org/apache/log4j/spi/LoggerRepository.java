package org.apache.log4j.spi;

import java.util.*;
import org.apache.log4j.*;

public interface LoggerRepository{
    void addHierarchyEventListener(HierarchyEventListener p0);
    boolean isDisabled(int p0);
    void setThreshold(Level p0);
    void setThreshold(String p0);
    void emitNoAppenderWarning(Category p0);
    Level getThreshold();
    Logger getLogger(String p0);
    Logger getLogger(String p0,LoggerFactory p1);
    Logger getRootLogger();
    Logger exists(String p0);
    void shutdown();
    Enumeration getCurrentLoggers();
    Enumeration getCurrentCategories();
    void fireAddAppenderEvent(Category p0,Appender p1);
    void resetConfiguration();
}
