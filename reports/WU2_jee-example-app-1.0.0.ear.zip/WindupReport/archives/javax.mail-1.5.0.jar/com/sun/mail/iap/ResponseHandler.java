package com.sun.mail.iap;

public interface ResponseHandler{
    void handleResponse(Response p0);
}
