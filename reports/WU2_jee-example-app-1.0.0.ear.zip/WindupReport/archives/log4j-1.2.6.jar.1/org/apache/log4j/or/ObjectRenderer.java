package org.apache.log4j.or;

public interface ObjectRenderer{
    String doRender(Object p0);
}
