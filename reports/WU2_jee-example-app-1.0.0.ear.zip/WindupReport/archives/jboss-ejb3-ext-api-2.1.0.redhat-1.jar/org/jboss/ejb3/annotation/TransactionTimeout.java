package org.jboss.ejb3.annotation;

import java.lang.annotation.*;
import java.util.concurrent.*;

@Target({ ElementType.METHOD,ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
public @interface TransactionTimeout{
    long value() default 0L;
    TimeUnit unit() default TimeUnit.SECONDS;
}
