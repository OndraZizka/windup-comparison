// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: fullnames 
// Source File Name:   ProductCatalogBean.java

package com.acme.anvil.service;

import java.rmi.RemoteException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import org.apache.log4j.Logger;

public class ProductCatalogBean
    implements javax.ejb.SessionBean
{

    public ProductCatalogBean()
    {
    }

    public void setSessionContext(javax.ejb.SessionContext ctx)
        throws javax.ejb.EJBException, java.rmi.RemoteException
    {
        sessionContext = sessionContext;
    }

    public void ejbRemove()
        throws javax.ejb.EJBException, java.rmi.RemoteException
    {
        LOG.info("Called Remove.");
    }

    public void ejbActivate()
        throws javax.ejb.EJBException, java.rmi.RemoteException
    {
        LOG.info("Called Activate");
    }

    public void ejbPassivate()
        throws javax.ejb.EJBException, java.rmi.RemoteException
    {
        LOG.info("Called Passivate");
    }

    public void populateCatalog()
    {
        LOG.info("Do something.");
    }

    static java.lang.Class _mthclass$(java.lang.String s)
    {
        try
        {
            return java.lang.Class.forName(s);
        }
        catch(java.lang.ClassNotFoundException classnotfoundexception)
        {
            throw new NoClassDefFoundError(classnotfoundexception.getMessage());
        }
    }

    private static final org.apache.log4j.Logger LOG;
    private javax.ejb.SessionContext sessionContext;

    static 
    {
        LOG = org.apache.log4j.Logger.getLogger(com.acme.anvil.service.ProductCatalogBean.class);
    }
}
