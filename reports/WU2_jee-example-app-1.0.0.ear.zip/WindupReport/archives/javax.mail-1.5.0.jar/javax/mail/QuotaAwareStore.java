package javax.mail;

public interface QuotaAwareStore{
    Quota[] getQuota(String p0) throws MessagingException;
    void setQuota(Quota p0) throws MessagingException;
}
