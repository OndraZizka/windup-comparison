package javax.ejb;

public class CreateException extends Exception{
    private static final long serialVersionUID=6295951740865457514L;
    public CreateException(){
        super();
    }
    public CreateException(final String message){
        super(message);
    }
}
