package javax.mail.internet;

import java.io.*;

public interface SharedInputStream{
    long getPosition();
    InputStream newStream(long p0,long p1);
}
