package javax.websocket;

public class DeploymentException extends Exception{
    public DeploymentException(final String message){
        super(message);
    }
    public DeploymentException(final String message,final Throwable cause){
        super(message,cause);
    }
}
