package javax.websocket;

import java.util.*;

public interface ClientEndpointConfig extends EndpointConfig{
    List<String> getPreferredSubprotocols();
    List<Extension> getExtensions();
    Configurator getConfigurator();
    public static class Configurator{
        public void beforeRequest(Map<String,List<String>> headers){
        }
        public void afterResponse(HandshakeResponse hr){
        }
    }
    public static final class Builder{
        private List<String> preferredSubprotocols;
        private List<Extension> extensions;
        private List<Class<? extends Encoder>> encoders;
        private List<Class<? extends Decoder>> decoders;
        private Configurator clientEndpointConfigurator;
        private Builder(){
            super();
            this.preferredSubprotocols=(List<String>)Collections.emptyList();
            this.extensions=(List<Extension>)Collections.emptyList();
            this.encoders=(List<Class<? extends Encoder>>)Collections.emptyList();
            this.decoders=(List<Class<? extends Decoder>>)Collections.emptyList();
            this.clientEndpointConfigurator=new Configurator() {};
        }
        public static Builder create(){
            return new Builder();
        }
        public ClientEndpointConfig build(){
            return new DefaultClientEndpointConfig((List<String>)Collections.unmodifiableList(this.preferredSubprotocols),(List<Extension>)Collections.unmodifiableList(this.extensions),(List<Class<? extends Encoder>>)Collections.unmodifiableList(this.encoders),(List<Class<? extends Decoder>>)Collections.unmodifiableList(this.decoders),this.clientEndpointConfigurator);
        }
        public Builder configurator(Configurator clientEndpointConfigurator){
            this.clientEndpointConfigurator=clientEndpointConfigurator;
            return this;
        }
        public Builder preferredSubprotocols(List<String> preferredSubprotocols){
            this.preferredSubprotocols=(List<String>)((preferredSubprotocols==null)?new ArrayList():preferredSubprotocols);
            return this;
        }
        public Builder extensions(List<Extension> extensions){
            this.extensions=(List<Extension>)((extensions==null)?new ArrayList():extensions);
            return this;
        }
        public Builder encoders(List<Class<? extends Encoder>> encoders){
            this.encoders=(List<Class<? extends Encoder>>)((encoders==null)?new ArrayList():encoders);
            return this;
        }
        public Builder decoders(List<Class<? extends Decoder>> decoders){
            this.decoders=(List<Class<? extends Decoder>>)((decoders==null)?new ArrayList():decoders);
            return this;
        }
    }
}
