package org.apache.log4j.lf5.viewer;

import java.awt.event.*;
import javax.swing.*;
import java.awt.*;

public class LogFactor5ErrorDialog extends LogFactor5Dialog{
    public LogFactor5ErrorDialog(final JFrame jframe,final String message){
        super(jframe,"Error",true);
        final JButton ok=new JButton("Ok");
        ok.addActionListener(new ActionListener(){
            public void actionPerformed(final ActionEvent e){
                LogFactor5ErrorDialog.this.hide();
            }
        });
        final JPanel bottom=new JPanel();
        bottom.setLayout(new FlowLayout());
        bottom.add(ok);
        final JPanel main=new JPanel();
        main.setLayout(new GridBagLayout());
        this.wrapStringOnPanel(message,main);
        this.getContentPane().add(main,"Center");
        this.getContentPane().add(bottom,"South");
        this.show();
    }
}
