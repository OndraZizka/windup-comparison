package javax.ejb;

import java.io.*;
import java.rmi.*;

public interface HomeHandle extends Serializable{
    EJBHome getEJBHome() throws RemoteException;
}
