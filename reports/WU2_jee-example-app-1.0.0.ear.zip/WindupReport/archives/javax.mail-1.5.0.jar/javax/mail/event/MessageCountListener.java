package javax.mail.event;

import java.util.*;

public interface MessageCountListener extends EventListener{
    void messagesAdded(MessageCountEvent p0);
    void messagesRemoved(MessageCountEvent p0);
}
