package javax.ejb;

public class EJBTransactionRolledbackException extends EJBException{
    private static final long serialVersionUID=-8301720350425840333L;
    public EJBTransactionRolledbackException(){
        super();
    }
    public EJBTransactionRolledbackException(final String message){
        super(message);
    }
    public EJBTransactionRolledbackException(final String message,final Exception ex){
        super(message,ex);
    }
}
