package javax.ejb;

import java.lang.annotation.*;

@Target({ ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
public @interface Singleton{
    String name() default "";
    String mappedName() default "";
    String description() default "";
}
