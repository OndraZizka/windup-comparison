package javax.ejb;

public class NoMoreTimeoutsException extends EJBException{
    private static final long serialVersionUID=1373788283844991998L;
    public NoMoreTimeoutsException(){
        super();
    }
    public NoMoreTimeoutsException(final String message){
        super(message);
    }
}
