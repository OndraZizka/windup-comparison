package javax.ejb;

public class AccessLocalException extends EJBException{
    private static final long serialVersionUID=-4089104928924996726L;
    public AccessLocalException(){
        super();
    }
    public AccessLocalException(final String message){
        super(message);
    }
    public AccessLocalException(final String message,final Exception ex){
        super(message,ex);
    }
}
