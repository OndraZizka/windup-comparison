package javax.ejb;

import java.rmi.*;

public interface SessionSynchronization{
    void afterBegin() throws EJBException,RemoteException;
    void beforeCompletion() throws EJBException,RemoteException;
    void afterCompletion(boolean p0) throws EJBException,RemoteException;
}
