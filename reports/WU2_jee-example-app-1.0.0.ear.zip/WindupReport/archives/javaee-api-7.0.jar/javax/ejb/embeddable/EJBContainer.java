package javax.ejb.embeddable;

import javax.ejb.spi.*;
import javax.ejb.*;
import java.util.*;
import javax.naming.*;
import java.io.*;

public abstract class EJBContainer implements AutoCloseable{
    public static final String PROVIDER="javax.ejb.embeddable.provider";
    public static final String MODULES="javax.ejb.embeddable.modules";
    public static final String APP_NAME="javax.ejb.embeddable.appName";
    private static final String newLine="\r\n";
    private static final ServiceLoader<EJBContainerProvider> providers;
    public static EJBContainer createEJBContainer(){
        return createEJBContainer(null);
    }
    public static EJBContainer createEJBContainer(final Map<?,?> properties){
        EJBContainer container=null;
        final Map<String,String> errors=(Map<String,String>)new HashMap();
        final Set<String> returnedNull=(Set<String>)new HashSet();
        EJBContainer.providers.reload();
        for(final EJBContainerProvider provider : EJBContainer.providers){
            try{
                container=provider.createEJBContainer(properties);
                if(container!=null){
                    break;
                }
                returnedNull.add(provider.getClass().getName());
            }
            catch(EJBException e){
                throw e;
            }
            catch(Throwable t){
                errors.put(provider.getClass().getName(),createErrorMessage(t));
            }
        }
        if(container==null){
            reportError(properties,errors,returnedNull);
        }
        return container;
    }
    public abstract Context getContext();
    @Override
    public abstract void close();
    private static void reportError(final Map<?,?> properties,final Map<String,String> errors,final Set<String> returnedNull) throws EJBException{
        final StringBuffer message=new StringBuffer("No EJBContainer provider available");
        if(properties!=null){
            final Object specifiedProvider=properties.get("javax.ejb.embeddable.provider");
            if(specifiedProvider!=null){
                message.append(" for requested provider: "+specifiedProvider);
            }
        }
        if(errors.isEmpty()&&returnedNull.isEmpty()){
            message.append(": no provider names had been found.");
        }
        else{
            message.append("\n");
        }
        for(final Map.Entry me : errors.entrySet()){
            message.append("Provider named ");
            message.append(me.getKey());
            message.append(" threw unexpected exception at create EJBContainer: \n");
            message.append(me.getValue()).append("\n");
        }
        if(!returnedNull.isEmpty()){
            message.append("The following providers:\n");
            for(final String n : returnedNull){
                message.append(n).append("\n");
            }
            message.append("Returned null from createEJBContainer call.\n");
        }
        throw new EJBException(message.toString());
    }
    private static String createErrorMessage(final Throwable t){
        final StringWriter errorMessage=new StringWriter();
        errorMessage.append((CharSequence)t.getClass().getName()).append((CharSequence)"\r\n");
        t.printStackTrace(new PrintWriter(errorMessage));
        errorMessage.append((CharSequence)"\r\n");
        return errorMessage.toString();
    }
    static{
        providers=ServiceLoader.load((Class<EJBContainerProvider>)EJBContainerProvider.class);
    }
}
