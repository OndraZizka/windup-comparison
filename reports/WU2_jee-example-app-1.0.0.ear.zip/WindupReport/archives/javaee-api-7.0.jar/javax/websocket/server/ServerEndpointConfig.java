package javax.websocket.server;

import javax.websocket.*;
import java.util.*;

public interface ServerEndpointConfig extends EndpointConfig{
    Class<?> getEndpointClass();
    String getPath();
    List<String> getSubprotocols();
    List<Extension> getExtensions();
    Configurator getConfigurator();
    public static class Configurator{
        private Configurator containerDefaultConfigurator;
        static Configurator fetchContainerDefaultConfigurator(){
            Iterator i$;
            Configurator impl;
            i$=ServiceLoader.load((Class<Configurator>)Configurator.class).iterator();
            if(i$.hasNext()){
                impl=(Configurator)i$.next();
                return impl;
            }
            throw new RuntimeException("Cannot load platform configurator");
        }
        Configurator getContainerDefaultConfigurator(){
            if(this.containerDefaultConfigurator==null){
                this.containerDefaultConfigurator=fetchContainerDefaultConfigurator();
            }
            return this.containerDefaultConfigurator;
        }
        public String getNegotiatedSubprotocol(List<String> supported,List<String> requested){
            return this.getContainerDefaultConfigurator().getNegotiatedSubprotocol(supported,requested);
        }
        public List<Extension> getNegotiatedExtensions(List<Extension> installed,List<Extension> requested){
            return this.getContainerDefaultConfigurator().getNegotiatedExtensions(installed,requested);
        }
        public boolean checkOrigin(String originHeaderValue){
            return this.getContainerDefaultConfigurator().checkOrigin(originHeaderValue);
        }
        public void modifyHandshake(ServerEndpointConfig sec,HandshakeRequest request,HandshakeResponse response){
        }
        public <T> T getEndpointInstance(Class<T> endpointClass) throws InstantiationException{
            return (T)this.getContainerDefaultConfigurator().getEndpointInstance((Class<Object>)endpointClass);
        }
    }
    public static final class Builder{
        private String path;
        private Class<?> endpointClass;
        private List<String> subprotocols;
        private List<Extension> extensions;
        private List<Class<? extends Encoder>> encoders;
        private List<Class<? extends Decoder>> decoders;
        private Configurator serverEndpointConfigurator;
        public static Builder create(Class<?> endpointClass,String path){
            return new Builder(endpointClass,path);
        }
        private Builder(){
            super();
            this.subprotocols=(List<String>)Collections.emptyList();
            this.extensions=(List<Extension>)Collections.emptyList();
            this.encoders=(List<Class<? extends Encoder>>)Collections.emptyList();
            this.decoders=(List<Class<? extends Decoder>>)Collections.emptyList();
        }
        public ServerEndpointConfig build(){
            return new DefaultServerEndpointConfig(this.endpointClass,this.path,(List<String>)Collections.unmodifiableList(this.subprotocols),(List<Extension>)Collections.unmodifiableList(this.extensions),(List<Class<? extends Encoder>>)Collections.unmodifiableList(this.encoders),(List<Class<? extends Decoder>>)Collections.unmodifiableList(this.decoders),this.serverEndpointConfigurator);
        }
        private Builder(Class endpointClass,String path){
            super();
            this.subprotocols=(List<String>)Collections.emptyList();
            this.extensions=(List<Extension>)Collections.emptyList();
            this.encoders=(List<Class<? extends Encoder>>)Collections.emptyList();
            this.decoders=(List<Class<? extends Decoder>>)Collections.emptyList();
            if(endpointClass==null){
                throw new IllegalArgumentException("endpointClass cannot be null");
            }
            this.endpointClass=(Class<?>)endpointClass;
            if(path==null||!path.startsWith("/")){
                throw new IllegalStateException("Path cannot be null and must begin with /");
            }
            this.path=path;
        }
        public Builder encoders(List<Class<? extends Encoder>> encoders){
            this.encoders=(List<Class<? extends Encoder>>)((encoders==null)?new ArrayList():encoders);
            return this;
        }
        public Builder decoders(List<Class<? extends Decoder>> decoders){
            this.decoders=(List<Class<? extends Decoder>>)((decoders==null)?new ArrayList():decoders);
            return this;
        }
        public Builder subprotocols(List<String> subprotocols){
            this.subprotocols=(List<String>)((subprotocols==null)?new ArrayList():subprotocols);
            return this;
        }
        public Builder extensions(List<Extension> extensions){
            this.extensions=(List<Extension>)((extensions==null)?new ArrayList():extensions);
            return this;
        }
        public Builder configurator(Configurator serverEndpointConfigurator){
            this.serverEndpointConfigurator=serverEndpointConfigurator;
            return this;
        }
    }
}
