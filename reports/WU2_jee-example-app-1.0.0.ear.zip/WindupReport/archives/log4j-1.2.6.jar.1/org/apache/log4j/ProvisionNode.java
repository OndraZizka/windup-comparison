package org.apache.log4j;

import java.util.*;

class ProvisionNode extends Vector{
    ProvisionNode(final Logger logger){
        super();
        this.addElement(logger);
    }
}
