package org.apache.log4j;

import org.apache.log4j.spi.*;

public interface Appender{
    void addFilter(Filter p0);
    Filter getFilter();
    void clearFilters();
    void close();
    void doAppend(LoggingEvent p0);
    String getName();
    void setErrorHandler(ErrorHandler p0);
    ErrorHandler getErrorHandler();
    void setLayout(Layout p0);
    Layout getLayout();
    void setName(String p0);
    boolean requiresLayout();
}
