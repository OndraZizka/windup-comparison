// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: fullnames 
// Source File Name:   LoginFilter.java

package com.acme.anvil;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.jboss.logging.Logger;

public class LoginFilter
    implements javax.servlet.Filter
{

    public LoginFilter()
    {
    }

    public void destroy()
    {
        log.debug("LoginFilter destroy.");
    }

    public void doFilter(javax.servlet.ServletRequest req, javax.servlet.ServletResponse resp, javax.servlet.FilterChain chain)
        throws java.io.IOException, javax.servlet.ServletException
    {
        javax.servlet.http.HttpServletRequest request = (javax.servlet.http.HttpServletRequest)req;
        javax.servlet.http.HttpServletResponse response = (javax.servlet.http.HttpServletResponse)resp;
        javax.servlet.http.HttpSession session = request.getSession();
    }

    public void init(javax.servlet.FilterConfig config)
        throws javax.servlet.ServletException
    {
        log.debug("LoginFilter init.");
    }

    static java.lang.Class _mthclass$(java.lang.String s)
    {
        try
        {
            return java.lang.Class.forName(s);
        }
        catch(java.lang.ClassNotFoundException classnotfoundexception)
        {
            throw new NoClassDefFoundError(classnotfoundexception.getMessage());
        }
    }

    private static final org.jboss.logging.Logger log;

    static 
    {
        log = org.jboss.logging.Logger.getLogger(com.acme.anvil.LoginFilter.class);
    }
}
