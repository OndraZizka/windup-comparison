package com.sun.mail.iap;

class AString{
    byte[] bytes;
    AString(final byte[] b){
        super();
        this.bytes=b;
    }
}
