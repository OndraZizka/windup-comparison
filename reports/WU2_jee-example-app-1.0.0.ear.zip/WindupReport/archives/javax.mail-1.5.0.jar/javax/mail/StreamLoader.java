package javax.mail;

import java.io.*;

interface StreamLoader{
    void load(InputStream p0) throws IOException;
}
