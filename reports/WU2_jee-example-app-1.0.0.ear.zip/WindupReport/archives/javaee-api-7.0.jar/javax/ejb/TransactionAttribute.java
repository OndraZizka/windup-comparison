package javax.ejb;

import java.lang.annotation.*;

@Target({ ElementType.METHOD,ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
public @interface TransactionAttribute{
    TransactionAttributeType value() default TransactionAttributeType.REQUIRED;
}
