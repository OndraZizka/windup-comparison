package com.sun.mail.pop3;

class Status{
    int total;
    int size;
    Status(){
        super();
        this.total=0;
        this.size=0;
    }
}
