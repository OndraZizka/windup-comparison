package javax.websocket.server;

import java.util.*;
import javax.websocket.*;

final class DefaultServerEndpointConfig implements ServerEndpointConfig{
    private String path;
    private Class<?> endpointClass;
    private List<String> subprotocols;
    private List<Extension> extensions;
    private List<Class<? extends Encoder>> encoders;
    private List<Class<? extends Decoder>> decoders;
    private Map<String,Object> userProperties;
    private Configurator serverEndpointConfigurator;
    DefaultServerEndpointConfig(final Class<?> endpointClass,final String path,final List<String> subprotocols,final List<Extension> extensions,final List<Class<? extends Encoder>> encoders,final List<Class<? extends Decoder>> decoders,final Configurator serverEndpointConfigurator){
        super();
        this.userProperties=(Map<String,Object>)new HashMap();
        this.path=path;
        this.endpointClass=endpointClass;
        this.subprotocols=(List<String>)Collections.unmodifiableList(subprotocols);
        this.extensions=(List<Extension>)Collections.unmodifiableList(extensions);
        this.encoders=(List<Class<? extends Encoder>>)Collections.unmodifiableList(encoders);
        this.decoders=(List<Class<? extends Decoder>>)Collections.unmodifiableList(decoders);
        if(serverEndpointConfigurator==null){
            this.serverEndpointConfigurator=Configurator.fetchContainerDefaultConfigurator();
        }
        else{
            this.serverEndpointConfigurator=serverEndpointConfigurator;
        }
    }
    @Override
    public Class<?> getEndpointClass(){
        return this.endpointClass;
    }
    DefaultServerEndpointConfig(final Class<? extends Endpoint> endpointClass,final String path){
        super();
        this.userProperties=(Map<String,Object>)new HashMap();
        this.path=path;
        this.endpointClass=endpointClass;
    }
    @Override
    public List<Class<? extends Encoder>> getEncoders(){
        return this.encoders;
    }
    @Override
    public List<Class<? extends Decoder>> getDecoders(){
        return this.decoders;
    }
    @Override
    public String getPath(){
        return this.path;
    }
    @Override
    public Configurator getConfigurator(){
        return this.serverEndpointConfigurator;
    }
    @Override
    public final Map<String,Object> getUserProperties(){
        return this.userProperties;
    }
    @Override
    public final List<String> getSubprotocols(){
        return this.subprotocols;
    }
    @Override
    public final List<Extension> getExtensions(){
        return this.extensions;
    }
}
