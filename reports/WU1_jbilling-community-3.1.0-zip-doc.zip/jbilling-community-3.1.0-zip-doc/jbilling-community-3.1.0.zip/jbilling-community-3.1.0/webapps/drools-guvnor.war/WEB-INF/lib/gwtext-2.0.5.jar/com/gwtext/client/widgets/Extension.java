package com.gwtext.client.widgets;

public interface Extension {
}
