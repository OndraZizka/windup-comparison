package com.sun.mail.imap.protocol;

public interface Item{
}
