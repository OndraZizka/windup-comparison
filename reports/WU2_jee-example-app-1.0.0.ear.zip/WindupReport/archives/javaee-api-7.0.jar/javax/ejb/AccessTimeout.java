package javax.ejb;

import java.lang.annotation.*;
import java.util.concurrent.*;

@Target({ ElementType.METHOD,ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
public @interface AccessTimeout{
    long value();
    TimeUnit unit() default TimeUnit.MILLISECONDS;
}
