package javax.ejb;

import java.io.*;
import java.util.*;

public class ScheduleExpression implements Serializable{
    private static final long serialVersionUID=-3813254457230997879L;
    private String second_;
    private String minute_;
    private String hour_;
    private String dayOfMonth_;
    private String month_;
    private String dayOfWeek_;
    private String year_;
    private String timezoneID_;
    private Date start_;
    private Date end_;
    public ScheduleExpression(){
        super();
        this.second_="0";
        this.minute_="0";
        this.hour_="0";
        this.dayOfMonth_="*";
        this.month_="*";
        this.dayOfWeek_="*";
        this.year_="*";
        this.timezoneID_=null;
        this.start_=null;
        this.end_=null;
    }
    public ScheduleExpression second(final String s){
        this.second_=s;
        return this;
    }
    public ScheduleExpression second(final int s){
        this.second_=s+"";
        return this;
    }
    public String getSecond(){
        return this.second_;
    }
    public ScheduleExpression minute(final String m){
        this.minute_=m;
        return this;
    }
    public ScheduleExpression minute(final int m){
        this.minute_=m+"";
        return this;
    }
    public String getMinute(){
        return this.minute_;
    }
    public ScheduleExpression hour(final String h){
        this.hour_=h;
        return this;
    }
    public ScheduleExpression hour(final int h){
        this.hour_=h+"";
        return this;
    }
    public String getHour(){
        return this.hour_;
    }
    public ScheduleExpression dayOfMonth(final String d){
        this.dayOfMonth_=d;
        return this;
    }
    public ScheduleExpression dayOfMonth(final int d){
        this.dayOfMonth_=d+"";
        return this;
    }
    public String getDayOfMonth(){
        return this.dayOfMonth_;
    }
    public ScheduleExpression month(final String m){
        this.month_=m;
        return this;
    }
    public ScheduleExpression month(final int m){
        this.month_=m+"";
        return this;
    }
    public String getMonth(){
        return this.month_;
    }
    public ScheduleExpression dayOfWeek(final String d){
        this.dayOfWeek_=d;
        return this;
    }
    public ScheduleExpression dayOfWeek(final int d){
        this.dayOfWeek_=d+"";
        return this;
    }
    public String getDayOfWeek(){
        return this.dayOfWeek_;
    }
    public ScheduleExpression year(final String y){
        this.year_=y;
        return this;
    }
    public ScheduleExpression year(final int y){
        this.year_=y+"";
        return this;
    }
    public String getYear(){
        return this.year_;
    }
    public ScheduleExpression timezone(final String timezoneID){
        this.timezoneID_=timezoneID;
        return this;
    }
    public String getTimezone(){
        return this.timezoneID_;
    }
    public ScheduleExpression start(final Date s){
        this.start_=((s==null)?null:new Date(s.getTime()));
        return this;
    }
    public Date getStart(){
        return (this.start_==null)?null:new Date(this.start_.getTime());
    }
    public ScheduleExpression end(final Date e){
        this.end_=((e==null)?null:new Date(e.getTime()));
        return this;
    }
    public Date getEnd(){
        return (this.end_==null)?null:new Date(this.end_.getTime());
    }
    @Override
    public String toString(){
        return "ScheduleExpression [second="+this.second_+";minute="+this.minute_+";hour="+this.hour_+";dayOfMonth="+this.dayOfMonth_+";month="+this.month_+";dayOfWeek="+this.dayOfWeek_+";year="+this.year_+";timezoneID="+this.timezoneID_+";start="+this.start_+";end="+this.end_+"]";
    }
}
