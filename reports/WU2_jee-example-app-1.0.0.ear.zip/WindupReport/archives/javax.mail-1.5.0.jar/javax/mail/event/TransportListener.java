package javax.mail.event;

import java.util.*;

public interface TransportListener extends EventListener{
    void messageDelivered(TransportEvent p0);
    void messageNotDelivered(TransportEvent p0);
    void messagePartiallyDelivered(TransportEvent p0);
}
