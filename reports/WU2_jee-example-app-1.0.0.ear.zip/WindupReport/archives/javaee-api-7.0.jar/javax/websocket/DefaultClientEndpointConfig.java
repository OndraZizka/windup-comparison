package javax.websocket;

import java.util.*;

final class DefaultClientEndpointConfig implements ClientEndpointConfig{
    private List<String> preferredSubprotocols;
    private List<Extension> extensions;
    private List<Class<? extends Encoder>> encoders;
    private List<Class<? extends Decoder>> decoders;
    private Map<String,Object> userProperties;
    private Configurator clientEndpointConfigurator;
    DefaultClientEndpointConfig(final List<String> preferredSubprotocols,final List<Extension> extensions,final List<Class<? extends Encoder>> encoders,final List<Class<? extends Decoder>> decoders,final Configurator clientEndpointConfigurator){
        super();
        this.userProperties=(Map<String,Object>)new HashMap();
        this.preferredSubprotocols=(List<String>)Collections.unmodifiableList(preferredSubprotocols);
        this.extensions=(List<Extension>)Collections.unmodifiableList(extensions);
        this.encoders=(List<Class<? extends Encoder>>)Collections.unmodifiableList(encoders);
        this.decoders=(List<Class<? extends Decoder>>)Collections.unmodifiableList(decoders);
        this.clientEndpointConfigurator=clientEndpointConfigurator;
    }
    @Override
    public List<String> getPreferredSubprotocols(){
        return this.preferredSubprotocols;
    }
    @Override
    public List<Extension> getExtensions(){
        return this.extensions;
    }
    @Override
    public List<Class<? extends Encoder>> getEncoders(){
        return this.encoders;
    }
    @Override
    public List<Class<? extends Decoder>> getDecoders(){
        return this.decoders;
    }
    @Override
    public final Map<String,Object> getUserProperties(){
        return this.userProperties;
    }
    @Override
    public Configurator getConfigurator(){
        return this.clientEndpointConfigurator;
    }
}
