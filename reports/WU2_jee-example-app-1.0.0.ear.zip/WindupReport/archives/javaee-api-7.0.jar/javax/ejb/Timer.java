package javax.ejb;

import java.util.*;
import java.io.*;

public interface Timer{
    void cancel() throws IllegalStateException,NoSuchObjectLocalException,EJBException;
    long getTimeRemaining() throws IllegalStateException,NoSuchObjectLocalException,NoMoreTimeoutsException,EJBException;
    Date getNextTimeout() throws IllegalStateException,NoSuchObjectLocalException,NoMoreTimeoutsException,EJBException;
    ScheduleExpression getSchedule() throws IllegalStateException,NoSuchObjectLocalException,EJBException;
    boolean isPersistent() throws IllegalStateException,NoSuchObjectLocalException,EJBException;
    boolean isCalendarTimer() throws IllegalStateException,NoSuchObjectLocalException,EJBException;
    Serializable getInfo() throws IllegalStateException,NoSuchObjectLocalException,EJBException;
    TimerHandle getHandle() throws IllegalStateException,NoSuchObjectLocalException,EJBException;
}
