package javax.mail;

import java.lang.annotation.*;

@Target({ ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
public @interface MailSessionDefinitions{
    MailSessionDefinition[] value();
}
