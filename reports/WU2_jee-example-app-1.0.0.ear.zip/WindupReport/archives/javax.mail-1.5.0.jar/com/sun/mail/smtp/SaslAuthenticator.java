package com.sun.mail.smtp;

import javax.mail.*;

public interface SaslAuthenticator{
    boolean authenticate(String[] p0,String p1,String p2,String p3,String p4) throws MessagingException;
}
