package javax.mail;

public interface UIDFolder{
    public static final long LASTUID=-1L;
    long getUIDValidity() throws MessagingException;
    Message getMessageByUID(long p0) throws MessagingException;
    Message[] getMessagesByUID(long p0,long p1) throws MessagingException;
    Message[] getMessagesByUID(long[] p0) throws MessagingException;
    long getUID(Message p0) throws MessagingException;
    public static class FetchProfileItem extends FetchProfile.Item{
        public static final FetchProfileItem UID;
        protected FetchProfileItem(String name){
            super(name);
        }
        static{
            UID=new FetchProfileItem("UID");
        }
    }
}
