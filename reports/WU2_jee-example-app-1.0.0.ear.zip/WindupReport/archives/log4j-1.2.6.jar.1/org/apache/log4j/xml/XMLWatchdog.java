package org.apache.log4j.xml;

import org.apache.log4j.helpers.*;
import org.apache.log4j.*;

class XMLWatchdog extends FileWatchdog{
    XMLWatchdog(final String filename){
        super(filename);
    }
    public void doOnChange(){
        new DOMConfigurator().doConfigure(super.filename,LogManager.getLoggerRepository());
    }
}
