package org.apache.log4j.spi;

public interface RepositorySelector{
    LoggerRepository getLoggerRepository();
}
