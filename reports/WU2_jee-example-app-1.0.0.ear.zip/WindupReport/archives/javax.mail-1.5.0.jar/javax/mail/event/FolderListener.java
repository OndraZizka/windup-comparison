package javax.mail.event;

import java.util.*;

public interface FolderListener extends EventListener{
    void folderCreated(FolderEvent p0);
    void folderDeleted(FolderEvent p0);
    void folderRenamed(FolderEvent p0);
}
