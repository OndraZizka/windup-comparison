package javax.ejb;

import java.lang.annotation.*;
import java.util.concurrent.*;

@Target({ ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
public @interface StatefulTimeout{
    long value();
    TimeUnit unit() default TimeUnit.MINUTES;
}
