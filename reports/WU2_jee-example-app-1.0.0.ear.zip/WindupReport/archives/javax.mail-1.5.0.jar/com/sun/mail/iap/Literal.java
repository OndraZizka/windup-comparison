package com.sun.mail.iap;

import java.io.*;

public interface Literal{
    int size();
    void writeTo(OutputStream p0) throws IOException;
}
