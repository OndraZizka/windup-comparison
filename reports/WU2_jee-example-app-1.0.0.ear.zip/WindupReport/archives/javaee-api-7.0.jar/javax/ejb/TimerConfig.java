package javax.ejb;

import java.io.*;

public class TimerConfig{
    private Serializable info_;
    private boolean persistent_;
    public TimerConfig(){
        super();
        this.info_=null;
        this.persistent_=true;
    }
    public TimerConfig(final Serializable info,final boolean persistent){
        super();
        this.info_=null;
        this.persistent_=true;
        this.info_=info;
        this.persistent_=persistent;
    }
    public void setInfo(final Serializable i){
        this.info_=i;
    }
    public Serializable getInfo(){
        return this.info_;
    }
    public void setPersistent(final boolean p){
        this.persistent_=p;
    }
    public boolean isPersistent(){
        return this.persistent_;
    }
    @Override
    public String toString(){
        return "TimerConfig [persistent="+this.persistent_+";info="+this.info_+"]";
    }
}
