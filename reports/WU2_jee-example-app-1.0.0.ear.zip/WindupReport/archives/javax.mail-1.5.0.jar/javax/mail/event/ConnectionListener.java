package javax.mail.event;

import java.util.*;

public interface ConnectionListener extends EventListener{
    void opened(ConnectionEvent p0);
    void disconnected(ConnectionEvent p0);
    void closed(ConnectionEvent p0);
}
