package com.sun.mail.util;

import java.io.*;
import javax.mail.*;

public interface ReadableMime{
    InputStream getMimeStream() throws MessagingException;
}
