package javax.ejb;

import java.lang.annotation.*;

@Target({ ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
public @interface MessageDriven{
    String name() default "";
    Class messageListenerInterface() default Object.class;
    ActivationConfigProperty[] activationConfig() default {};
    String mappedName() default "";
    String description() default "";
}
