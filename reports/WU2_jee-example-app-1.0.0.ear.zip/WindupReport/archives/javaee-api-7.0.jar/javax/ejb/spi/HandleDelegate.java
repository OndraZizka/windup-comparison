package javax.ejb.spi;

import java.io.*;
import javax.ejb.*;

public interface HandleDelegate{
    void writeEJBObject(EJBObject p0,ObjectOutputStream p1) throws IOException;
    EJBObject readEJBObject(ObjectInputStream p0) throws IOException,ClassNotFoundException;
    void writeEJBHome(EJBHome p0,ObjectOutputStream p1) throws IOException;
    EJBHome readEJBHome(ObjectInputStream p0) throws IOException,ClassNotFoundException;
}
