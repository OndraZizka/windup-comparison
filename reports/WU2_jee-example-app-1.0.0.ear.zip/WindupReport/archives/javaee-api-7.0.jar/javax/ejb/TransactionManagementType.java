package javax.ejb;

public enum TransactionManagementType{
    CONTAINER,BEAN;
}
