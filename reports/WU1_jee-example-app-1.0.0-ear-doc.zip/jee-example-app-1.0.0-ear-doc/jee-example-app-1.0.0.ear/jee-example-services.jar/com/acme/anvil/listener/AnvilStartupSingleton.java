// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: fullnames 
// Source File Name:   AnvilStartupSingleton.java

package com.acme.anvil.listener;

import com.acme.anvil.management.AnvilInvokeBeanImpl;
import java.lang.management.ManagementFactory;
import javax.management.MBeanServer;
import javax.management.ObjectName;
import javax.naming.NamingException;
import org.apache.log4j.Logger;

public class AnvilStartupSingleton
{

    public AnvilStartupSingleton()
    {
    }

    void postStart()
    {
        LOG.info((new StringBuilder()).append("After Start Application[").append(appName).append("]").toString());
        registerMBean();
    }

    void postStop()
    {
        LOG.info((new StringBuilder()).append("Before Stop Application[").append(appName).append("]").toString());
        unregisterMBean();
    }

    private javax.management.MBeanServer getMBeanServer()
        throws javax.naming.NamingException
    {
        javax.management.MBeanServer server = java.lang.management.ManagementFactory.getPlatformMBeanServer();
        return server;
    }

    private void registerMBean()
    {
        LOG.info("Registering MBeans.");
        try
        {
            javax.management.MBeanServer server = getMBeanServer();
            server.registerMBean(new AnvilInvokeBeanImpl(), new ObjectName("com.acme:Name=anvil,Type=com.acme.anvil.management.AnvilInvokeBean"));
            LOG.info("Registered MBean[com.acme:Name=anvil,Type=com.acme.anvil.management.AnvilInvokeBean]");
        }
        catch(java.lang.Exception e)
        {
            LOG.error("Exception while registering MBean[com.acme:Name=anvil,Type=com.acme.anvil.management.AnvilInvokeBean]");
        }
    }

    private void unregisterMBean()
    {
        LOG.info("Unregistering MBeans.");
        try
        {
            javax.management.MBeanServer server = getMBeanServer();
            server.unregisterMBean(new ObjectName("com.acme:Name=anvil,Type=com.acme.anvil.management.AnvilInvokeBean"));
            LOG.info("Unregistered MBean[com.acme:Name=anvil,Type=com.acme.anvil.management.AnvilInvokeBean]");
        }
        catch(java.lang.Exception e)
        {
            LOG.error("Exception while unregistering MBean[com.acme:Name=anvil,Type=com.acme.anvil.management.AnvilInvokeBean]");
        }
    }

    static java.lang.Class _mthclass$(java.lang.String s)
    {
        try
        {
            return java.lang.Class.forName(s);
        }
        catch(java.lang.ClassNotFoundException classnotfoundexception)
        {
            throw new NoClassDefFoundError(classnotfoundexception.getMessage());
        }
    }

    private static org.apache.log4j.Logger LOG;
    private static final java.lang.String MBEAN_NAME = "com.acme:Name=anvil,Type=com.acme.anvil.management.AnvilInvokeBean";
    private java.lang.String appName;

    static 
    {
        LOG = org.apache.log4j.Logger.getLogger(com.acme.anvil.listener.AnvilStartupSingleton.class);
    }
}
