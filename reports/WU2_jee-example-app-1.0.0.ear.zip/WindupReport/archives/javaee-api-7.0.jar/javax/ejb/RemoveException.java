package javax.ejb;

public class RemoveException extends Exception{
    private static final long serialVersionUID=-4581849053220157910L;
    public RemoveException(){
        super();
    }
    public RemoveException(final String message){
        super(message);
    }
}
