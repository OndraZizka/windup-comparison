package javax.mail;

class Version{
    public static final String version="1.5.0";
}
