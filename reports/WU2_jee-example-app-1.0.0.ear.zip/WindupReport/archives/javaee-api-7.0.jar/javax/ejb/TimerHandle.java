package javax.ejb;

import java.io.*;

public interface TimerHandle extends Serializable{
    Timer getTimer() throws IllegalStateException,NoSuchObjectLocalException,EJBException;
}
