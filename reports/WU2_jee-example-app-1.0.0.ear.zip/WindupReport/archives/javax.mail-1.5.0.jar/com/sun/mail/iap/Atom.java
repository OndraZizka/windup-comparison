package com.sun.mail.iap;

class Atom{
    String string;
    Atom(final String s){
        super();
        this.string=s;
    }
}
