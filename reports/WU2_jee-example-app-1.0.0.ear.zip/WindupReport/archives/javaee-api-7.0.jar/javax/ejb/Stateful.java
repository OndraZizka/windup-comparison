package javax.ejb;

import java.lang.annotation.*;

@Target({ ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
public @interface Stateful{
    String name() default "";
    String mappedName() default "";
    String description() default "";
    boolean passivationCapable() default true;
}
