package javax.mail;

public interface EncodingAware{
    String getEncoding();
}
