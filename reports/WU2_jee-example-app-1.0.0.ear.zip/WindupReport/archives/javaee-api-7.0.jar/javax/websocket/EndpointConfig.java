package javax.websocket;

import java.util.*;

public interface EndpointConfig{
    List<Class<? extends Encoder>> getEncoders();
    List<Class<? extends Decoder>> getDecoders();
    Map<String,Object> getUserProperties();
}
