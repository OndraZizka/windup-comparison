package javax.websocket;

import java.nio.*;

public interface PongMessage{
    ByteBuffer getApplicationData();
}
