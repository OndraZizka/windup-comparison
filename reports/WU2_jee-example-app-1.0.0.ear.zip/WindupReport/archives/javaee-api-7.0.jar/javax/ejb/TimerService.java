package javax.ejb;

import java.io.*;
import java.util.*;

public interface TimerService{
    Timer createTimer(long p0,Serializable p1) throws IllegalArgumentException,IllegalStateException,EJBException;
    Timer createSingleActionTimer(long p0,TimerConfig p1) throws IllegalArgumentException,IllegalStateException,EJBException;
    Timer createTimer(long p0,long p1,Serializable p2) throws IllegalArgumentException,IllegalStateException,EJBException;
    Timer createIntervalTimer(long p0,long p1,TimerConfig p2) throws IllegalArgumentException,IllegalStateException,EJBException;
    Timer createTimer(Date p0,Serializable p1) throws IllegalArgumentException,IllegalStateException,EJBException;
    Timer createSingleActionTimer(Date p0,TimerConfig p1) throws IllegalArgumentException,IllegalStateException,EJBException;
    Timer createTimer(Date p0,long p1,Serializable p2) throws IllegalArgumentException,IllegalStateException,EJBException;
    Timer createIntervalTimer(Date p0,long p1,TimerConfig p2) throws IllegalArgumentException,IllegalStateException,EJBException;
    Timer createCalendarTimer(ScheduleExpression p0) throws IllegalArgumentException,IllegalStateException,EJBException;
    Timer createCalendarTimer(ScheduleExpression p0,TimerConfig p1) throws IllegalArgumentException,IllegalStateException,EJBException;
    Collection<Timer> getTimers() throws IllegalStateException,EJBException;
    Collection<Timer> getAllTimers() throws IllegalStateException,EJBException;
}
