// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: fullnames 
// Source File Name:   AnvilWebListener.java

package com.acme.anvil.listener;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import javax.management.MBeanServerConnection;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;
import javax.naming.NamingException;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import org.jboss.logging.Logger;

public class AnvilWebListener
    implements javax.servlet.ServletContextListener
{

    public AnvilWebListener()
    {
    }

    public void contextInitialized(javax.servlet.ServletContextEvent sce)
    {
        log.info((new StringBuilder()).append("Initialized context, calling listener: ").append((com.acme.anvil.listener.AnvilWebListener.class).getSimpleName()).append(" with properties: ").toString());
        java.lang.String name;
        for(java.util.Enumeration names = sce.getServletContext().getAttributeNames(); names.hasMoreElements(); log.info((new StringBuilder()).append("Attribute[").append(name).append("] = Value[").append(sce.getServletContext().getAttribute(name)).append("]").toString()))
            name = (java.lang.String)names.nextElement();

    }

    public void contextDestroyed(javax.servlet.ServletContextEvent servletcontextevent)
    {
    }

    private javax.management.MBeanServerConnection getMBeanServerConn()
        throws javax.naming.NamingException, java.net.MalformedURLException, java.io.IOException
    {
        java.lang.String host = "localhost";
        int port = 9990;
        java.lang.String url = java.lang.System.getProperty("jmx.service.url", (new StringBuilder()).append("service:jmx:http-remoting-jmx://").append(host).append(":").append(port).toString());
        javax.management.remote.JMXServiceURL serviceURL = new JMXServiceURL(url);
        java.util.Map env = new HashMap();
        env.put("jmx.remote.credentials", new java.lang.String[] {
            "fred", "seafood"
        });
        javax.management.remote.JMXConnector jmxConnector = javax.management.remote.JMXConnectorFactory.connect(serviceURL, env);
        javax.management.MBeanServerConnection conn = jmxConnector.getMBeanServerConnection();
        return conn;
    }

    private static final java.lang.String MBEAN_NAME = "com.acme:Name=anvil,Type=com.acme.anvil.management.AnvilInvokeBeanT3StartupDef";
    private static final org.jboss.logging.Logger log;

    static 
    {
        log = org.jboss.logging.Logger.getLogger(com.acme.anvil.listener.AnvilWebListener.class);
    }
}
