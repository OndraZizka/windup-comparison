package javax.mail.event;

import java.util.*;

public interface StoreListener extends EventListener{
    void notification(StoreEvent p0);
}
