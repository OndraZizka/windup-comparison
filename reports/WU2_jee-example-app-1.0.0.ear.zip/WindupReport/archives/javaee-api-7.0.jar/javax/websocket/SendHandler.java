package javax.websocket;

public interface SendHandler{
    void onResult(SendResult p0);
}
