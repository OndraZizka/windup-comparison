package javax.websocket;

import java.lang.annotation.*;

@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.METHOD })
public @interface OnMessage{
    long maxMessageSize() default -1L;
}
