package org.apache.log4j.lf5.viewer.categoryexplorer;

import org.apache.log4j.lf5.*;
import javax.swing.tree.*;
import java.util.*;

public class CategoryExplorerLogRecordFilter implements LogRecordFilter{
    protected CategoryExplorerModel _model;
    public CategoryExplorerLogRecordFilter(final CategoryExplorerModel model){
        super();
        this._model=model;
    }
    public boolean passes(final LogRecord record){
        final CategoryPath path=new CategoryPath(record.getCategory());
        return this._model.isCategoryPathActive(path);
    }
    public void reset(){
        this.resetAllNodes();
    }
    protected void resetAllNodes(){
        final Enumeration nodes=this._model.getRootCategoryNode().depthFirstEnumeration();
        while(nodes.hasMoreElements()){
            final CategoryNode current=(CategoryNode)nodes.nextElement();
            current.resetNumberOfContainedRecords();
            this._model.nodeChanged(current);
        }
    }
}
