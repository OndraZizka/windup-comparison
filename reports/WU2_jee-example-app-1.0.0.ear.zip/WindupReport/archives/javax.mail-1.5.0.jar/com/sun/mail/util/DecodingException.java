package com.sun.mail.util;

import java.io.*;

public class DecodingException extends IOException{
    private static final long serialVersionUID=-6913647794421459390L;
    public DecodingException(final String s){
        super(s);
    }
}
