package javax.ejb;

public class TransactionRequiredLocalException extends EJBException{
    private static final long serialVersionUID=-3884174204131319153L;
    public TransactionRequiredLocalException(){
        super();
    }
    public TransactionRequiredLocalException(final String message){
        super(message);
    }
}
