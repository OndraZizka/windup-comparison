// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: fullnames 
// Source File Name:   LogEventPublisher.java

package com.acme.anvil.service.jms;

import com.acme.anvil.vo.LogEvent;
import javax.jms.JMSContext;
import javax.jms.JMSProducer;
import javax.jms.Queue;
import org.apache.log4j.Logger;
import weblogic.transaction.ClientTransactionManager;
import weblogic.transaction.TransactionHelper;

public class LogEventPublisher
{

    public LogEventPublisher()
    {
    }

    public void publishLogEvent(com.acme.anvil.vo.LogEvent logEvent)
    {
        weblogic.transaction.ClientTransactionManager ctm = weblogic.transaction.TransactionHelper.getTransactionHelper().getTransactionManager();
        javax.transaction.Transaction saveTx = null;
        try
        {
            saveTx = ctm.forceSuspend();
            javax.jms.ObjectMessage logMsg = context.createObjectMessage(logEvent);
            context.createProducer().send(myQueue, logMsg);
        }
        finally
        {
            ctm.forceResume(saveTx);
        }
    }

    static java.lang.Class _mthclass$(java.lang.String s)
    {
        try
        {
            return java.lang.Class.forName(s);
        }
        catch(java.lang.ClassNotFoundException classnotfoundexception)
        {
            throw new NoClassDefFoundError(classnotfoundexception.getMessage());
        }
    }

    private static final org.apache.log4j.Logger log;
    private static final java.lang.String QUEUE_JNDI_NAME = "java:jboss/jms/queue/LogEventQueue";
    private javax.jms.JMSContext context;
    javax.jms.Queue myQueue;

    static 
    {
        log = org.apache.log4j.Logger.getLogger(com.acme.anvil.service.jms.LogEventPublisher.class);
    }
}
