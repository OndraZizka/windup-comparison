package javax.mail.internet;

import javax.mail.*;
import java.util.*;

public interface MimePart extends Part{
    String getHeader(String p0,String p1) throws MessagingException;
    void addHeaderLine(String p0) throws MessagingException;
    Enumeration getAllHeaderLines() throws MessagingException;
    Enumeration getMatchingHeaderLines(String[] p0) throws MessagingException;
    Enumeration getNonMatchingHeaderLines(String[] p0) throws MessagingException;
    String getEncoding() throws MessagingException;
    String getContentID() throws MessagingException;
    String getContentMD5() throws MessagingException;
    void setContentMD5(String p0) throws MessagingException;
    String[] getContentLanguage() throws MessagingException;
    void setContentLanguage(String[] p0) throws MessagingException;
    void setText(String p0) throws MessagingException;
    void setText(String p0,String p1) throws MessagingException;
    void setText(String p0,String p1,String p2) throws MessagingException;
}
