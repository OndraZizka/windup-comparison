package javax.ejb;

public class NoSuchObjectLocalException extends EJBException{
    private static final long serialVersionUID=9151491108833037318L;
    public NoSuchObjectLocalException(){
        super();
    }
    public NoSuchObjectLocalException(final String message){
        super(message);
    }
    public NoSuchObjectLocalException(final String message,final Exception ex){
        super(message,ex);
    }
}
