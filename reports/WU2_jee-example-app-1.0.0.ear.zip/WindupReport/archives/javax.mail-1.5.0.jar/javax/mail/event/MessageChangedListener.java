package javax.mail.event;

import java.util.*;

public interface MessageChangedListener extends EventListener{
    void messageChanged(MessageChangedEvent p0);
}
