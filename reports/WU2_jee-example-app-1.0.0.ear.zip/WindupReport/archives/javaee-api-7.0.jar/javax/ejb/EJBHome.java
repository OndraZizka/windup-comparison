package javax.ejb;

import java.rmi.*;

public interface EJBHome extends Remote{
    void remove(Handle p0) throws RemoteException,RemoveException;
    void remove(Object p0) throws RemoteException,RemoveException;
    EJBMetaData getEJBMetaData() throws RemoteException;
    HomeHandle getHomeHandle() throws RemoteException;
}
