package javax.ejb;

import java.util.concurrent.*;

public final class AsyncResult<V> implements Future<V>{
    private final V resultValue;
    public AsyncResult(final V result){
        super();
        this.resultValue=result;
    }
    @Override
    public boolean cancel(final boolean mayInterruptIfRunning){
        throw new IllegalStateException("Object does not represent an acutal Future");
    }
    @Override
    public boolean isCancelled(){
        throw new IllegalStateException("Object does not represent an acutal Future");
    }
    @Override
    public boolean isDone(){
        throw new IllegalStateException("Object does not represent an acutal Future");
    }
    @Override
    public V get() throws InterruptedException,ExecutionException{
        return this.resultValue;
    }
    @Override
    public V get(final long timeout,final TimeUnit unit) throws InterruptedException,ExecutionException,TimeoutException{
        throw new IllegalStateException("Object does not represent an acutal Future");
    }
}
