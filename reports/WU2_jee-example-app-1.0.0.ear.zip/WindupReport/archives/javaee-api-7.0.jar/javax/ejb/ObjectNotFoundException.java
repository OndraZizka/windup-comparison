package javax.ejb;

public class ObjectNotFoundException extends FinderException{
    private static final long serialVersionUID=4624364141026778L;
    public ObjectNotFoundException(){
        super();
    }
    public ObjectNotFoundException(final String message){
        super(message);
    }
}
