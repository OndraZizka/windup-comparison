package org.apache.log4j.lf5.viewer.categoryexplorer;

import javax.swing.event.*;

public class TreeModelAdapter implements TreeModelListener{
    public void treeNodesChanged(final TreeModelEvent e){
    }
    public void treeNodesInserted(final TreeModelEvent e){
    }
    public void treeNodesRemoved(final TreeModelEvent e){
    }
    public void treeStructureChanged(final TreeModelEvent e){
    }
}
