package javax.websocket;

import java.util.*;

public interface Extension{
    String getName();
    List<Parameter> getParameters();
    public interface Parameter{
        String getName();
        String getValue();
    }
}
